import pygame
from ecran import *

# Ceci est déjà dans votre code
menu_options_rect_demarrage = []  # Ajoutez cette ligne si vous voulez gérer les clics dans le menu de démarrage

def afficher_menu_demarrage():
    global menu_options_rect_demarrage
    menu_font = pygame.font.Font(None, 36)
    menu_options = ["Démarrer le jeu", "Quitter"]  # Les options du menu de démarrage

    menu_surface = pygame.Surface((largeur // 3, hauteur // 3))
    menu_surface.set_alpha(200)
    menu_surface.fill((50, 50, 50))  # Couleur de fond du menu

    menu_rect = menu_surface.get_rect(center=(largeur // 2, hauteur // 2))
    fenetre.blit(menu_surface, menu_rect)

    menu_options_rect_demarrage = []  # Réinitialisez cette liste chaque fois que le menu est dessiné
    for i, option in enumerate(menu_options):
        texte_option = menu_font.render(option, True, (255, 255, 255))
        option_rect = texte_option.get_rect(center=(largeur // 2, hauteur // 2 + i * 40))
        if option_rect.collidepoint(pygame.mouse.get_pos()):
            texte_option = menu_font.render(option, True, (255, 0, 0))  # Changement de couleur pour l'option survolée
        fenetre.blit(texte_option, option_rect)
        menu_options_rect_demarrage.append(option_rect)

def afficher_menu_principal():
    global menu_options_rect_principal
    menu_font = pygame.font.Font(None, 36)
    menu_options = ["Continuer", "Paramètres", "Quitter"]

    menu_surface = pygame.Surface((largeur // 3, hauteur // 3))
    menu_surface.set_alpha(200)
    menu_surface.fill((50, 50, 50))

    menu_rect = menu_surface.get_rect(center=(largeur // 2, hauteur // 2))
    fenetre.blit(menu_surface, menu_rect)

    menu_options_rect_principal = []
    for i, option in enumerate(menu_options):
        texte_option = menu_font.render(option, True, (255, 255, 255))
        # suite de la fonction afficher_menu_principal()
        option_rect = texte_option.get_rect(center=(largeur // 2, hauteur // 2 + i * 50))
        if option_rect.collidepoint(pygame.mouse.get_pos()):
            texte_option = menu_font.render(option, True, (255, 0, 0))  # Changement de couleur pour l'option survolée

        fenetre.blit(texte_option, option_rect)
        menu_options_rect_principal.append(option_rect)
