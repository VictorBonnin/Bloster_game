import pygame

pygame.init()

pygame.mixer.init()

# -------------------------------------------------
# Musique d'ambiance

pygame.mixer.music.load("D:\\Projet\\A\\Audio\\mongol.mp3")
pygame.mixer.music.play(-1)
volume_son = 0.2

pygame.mixer.music.set_volume(volume_son)
def regler_volume_son(nouveau_volume):
    global volume_son
    volume_son = max(0, min(1, nouveau_volume))  # Assurez-vous que le volume est entre 0 et 1
    pygame.mixer.music.set_volume(volume_son)


# -------------------------------------------------
# Menus
    
click_sound = pygame.mixer.Sound("D:\\Projet\\A\\Audio\\menusound1.wav")
click_sound.set_volume(0.2)

# -------------------------------------------------
# Effets sonores pour les collisions

collision_sound = pygame.mixer.Sound("D:\\Projet\\A\\Audio\\auaua.wav")
collision_sound.set_volume(0.1)