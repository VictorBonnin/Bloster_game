import pygame
import random
from obstacle import *
from personnage import *

pygame.init()

# Variable pour le temps écoulé (en secondes)
temps_ecoule = 0

# Obtenir le temps actuel en millisecondes
temps_actuel = pygame.time.get_ticks()

def reinitialiser_jeu():
    global temps_ecoule, temps_actuel
    temps_ecoule = 0  # Remettre le temps écoulé à 0
    temps_actuel = pygame.time.get_ticks()  # Obtenir le nouveau temps de départ

    # Réinitialiser la position du personnage
    personnage_rect.x = largeur // 2
    personnage_rect.y = hauteur // 2

    # Réinitialiser la position des obstacles
    for obstacle in obstacles:
        obstacle.rect.x = random.randint(0, largeur - obstacle.rect.width)
        obstacle.rect.y = random.randint(0, hauteur - obstacle.rect.height)

    for obstacle2 in obstacles2:
        obstacle2.rect.x = random.randint(0, largeur - obstacle2.rect.width)
        obstacle2.rect.y = random.randint(0, hauteur - obstacle2.rect.height)

    for obstacle3 in obstacles3:
        obstacle3.rect.x = random.randint(0, largeur - obstacle3.rect.width)
        obstacle3.rect.y = random.randint(0, hauteur - obstacle3.rect.height)